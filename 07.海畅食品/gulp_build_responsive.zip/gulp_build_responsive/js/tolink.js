const toProduct = document.getElementById('toProduct');
const toService = document.getElementById('toService');
const h5_toProduct = document.getElementById('h5_toProduct');
const h5_toServe = document.getElementById('h5_toServe');

toService.addEventListener('click', () => {
    window.location.assign('./index.html')
});

toProduct.addEventListener('click', () => {
    window.location.assign('./index.html')
});

h5_toServe.addEventListener('click', () => {
    window.location.assign('./index.html')
});

h5_toProduct.addEventListener('click', () => {
    window.location.assign('./index.html')
});

