$(function () {

  AOS.init();

  NProgress.done();
});
